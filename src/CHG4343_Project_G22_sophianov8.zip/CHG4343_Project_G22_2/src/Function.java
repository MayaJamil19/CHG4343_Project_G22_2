public interface Function
{
    public double calculateValue(double x, double y, int n);
}
